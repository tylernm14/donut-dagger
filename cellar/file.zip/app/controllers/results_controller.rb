require_relative 'application_controller'
require 'will_paginate'
require 'will_paginate/active_record'
require 'sinatra/has_scope'

class ResultsController < ApplicationController
  WillPaginate.per_page = 50

  register Sinatra::HasScope
  has_scope :result, :by_job_id, :by_workflow_id #, :by_metadata, :search

  get '/' do
    results = apply_scopes(:result, Result, params).
        paginate(page: params[:page], per_page: params[:per_page])
    headers \
          "X-total"   => results.total_entries.to_s,
          "X-offset"  => results.offset.to_s,
          "X-limit"   => results.per_page.to_s

    json results
  end

  get '/:id' do
    json Result.find(params[:id])
  end

  post '/' do
    json Result.create!(allowed_params)
  end

  private

  def allowed_params
    params.delete_if {|k,_| !['zip_file', 'image', 'name', 'workflow_id', 'job_id'].include(k)}
  end

end