

ENV['APP_NAME'] = 'svcrhone' # MUST BE AT TOP
require 'svc/app/controllers/svc_application_controller'
require 'less'
require 'active_support/core_ext/time'

Svc::require_workers


class ApplicationController < SvcApplicationController

  get '/css/application.css' do
    content_type :css
    less :"css/application"
    # less File.join(ApplicationController.root, '/public/css').to_s
  end
  set :root, File.expand_path('..', '__FILE__')


  set :public_folder, 'public'


  set :show_exceptions, false
  set :views, File.expand_path('../../views', __FILE__)


  config_file ['../../config/*.erb',
               "#{Gem.loaded_specs['svc'].full_gem_path}/lib/svc/config/*.erb"]


  configure(:development) do
    also_reload "#{root}/lib/*.rb"
  end


end

