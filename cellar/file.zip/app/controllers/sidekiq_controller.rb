require 'sinatra/auth'
require 'sidekiq/web'

class SidekiqController < Sinatra::Base
  register Sinatra::Auth
end

